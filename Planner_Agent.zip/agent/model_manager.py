"""
agent/model_manager.py
Manages lifecycle of local Ollama models.

Spec requirement:
  - Only ONE model may be active at a time
  - Before switching, the current model must be stopped (releases VRAM)
  - Uses `ollama stop <model>` via subprocess

Context window tuned for RTX 4060 (8GB VRAM):
  llama3.1:8b      → 4096 tokens  (~4.9 GB base, 3.1 GB free — comfortable)
  qwen2.5-coder:7b → 4096 tokens  (~4.7 GB base, 3.3 GB free — comfortable)
  gemma4-e2b-it:latest       → 2048 tokens  (~7.2 GB base, 0.8 GB free — must limit)
"""

import subprocess
from langchain_ollama import ChatOllama

# Model registry — maps task type to model name
MODEL_MAP = {
    "general":       "llama3.1:8b",
    "coding":        "qwen2.5-coder:7b",
    "quick":         "gemma4-e2b-it:latest",   # fast answers for short/simple questions
    "large_context": "gemma4-e2b-it:latest",   # large context processing
}

# Per-model context window — tuned for 8GB VRAM
MODEL_CTX = {
    "llama3.1:8b":       4096,
    "qwen2.5-coder:7b":  4096,
    "gemma4-e2b-it:latest":        2048,
}


class ModelManager:
    """
    Singleton-style manager for Ollama model lifecycle.
    Ensures only one model is active at any time.
    """

    def __init__(self):
        self._current_model: str | None = None
        self._llm: ChatOllama | None = None

    def switch_to(self, task_type: str) -> "ModelManager":
        """
        Select the correct model for the given task type.
        Stops the currently running model first (if different).

        Args:
            task_type: "general", "coding", or "large_context"

        Returns:
            self (for chaining)
        """
        target_model = MODEL_MAP.get(task_type, MODEL_MAP["general"])

        if self._current_model == target_model:
            # Already on the right model — no switch needed
            return self

        # Stop the current model to release VRAM (spec requirement)
        if self._current_model is not None:
            self._stop_model(self._current_model)

        # Load the new model with the appropriate context window
        ctx = MODEL_CTX.get(target_model, 4096)
        print(f"  [ModelManager] Loading: {target_model}  (num_ctx={ctx})")
        self._current_model = target_model
        self._llm = ChatOllama(model=target_model, temperature=0, num_ctx=ctx)
        return self

    def switch_to_name(self, model_name: str) -> "ModelManager":
        """
        Directly switch to a model by name — used for manual user overrides.
        Bypasses the task_type → model_name lookup.
        """
        if self._current_model == model_name:
            return self
        if self._current_model is not None:
            self._stop_model(self._current_model)
        ctx = MODEL_CTX.get(model_name, 4096)
        print(f"  [ModelManager] Loading (manual override): {model_name}  (num_ctx={ctx})")
        self._current_model = model_name
        self._llm = ChatOllama(model=model_name, temperature=0, num_ctx=ctx)
        return self

    def get_llm(self) -> ChatOllama:
        """Return the currently active LLM. Must call switch_to() first."""
        if self._llm is None:
            raise RuntimeError("No model loaded. Call switch_to() first.")
        return self._llm

    def get_model_name(self) -> str | None:
        return self._current_model

    def _stop_model(self, model_name: str):
        """Stop a running Ollama model to release VRAM."""
        try:
            print(f"  [ModelManager] Stopping: {model_name}")
            subprocess.run(
                ["ollama", "stop", model_name],
                check=False,
                capture_output=True,
                timeout=10,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as e:
            print(f"  [ModelManager] Warning: Could not stop {model_name}: {e}")
