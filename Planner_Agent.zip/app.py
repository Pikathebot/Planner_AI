"""
app.py — Local AI Planning Agent (Gradio Web UI)
Run with: python app.py
Opens at: http://localhost:7860

Two modes:
  Tab 1 - Planner: Generate structured plans with rich markdown + download
  Tab 2 - Chat:    Conversational AI with a side panel for generated plans
"""

import warnings
import traceback
import tempfile
import os
warnings.filterwarnings("ignore", category=DeprecationWarning)

import gradio as gr
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from agent.classifier import classify_task
from agent.model_manager import ModelManager
from agent.search_gate import needs_search
from agent.planner import stream_planner, SYSTEM_PROMPT

# ── Constants ─────────────────────────────────────────────────────────────────
AUTO_CHOICE = "🤖 Auto (recommended)"
MODEL_OPTIONS = [AUTO_CHOICE, "llama3.1:8b", "qwen2.5-coder:7b", "gemma4-e2b-it:latest"]

MODEL_LABELS = {
    "general":       "llama3.1:8b",
    "coding":        "qwen2.5-coder:7b",
    "quick":         "gemma4-e2b-it:latest",
    "large_context": "gemma4-e2b-it:latest ",
}

TASK_BADGES = {
    "general":       "🧠 GENERAL",
    "coding":        "💻 CODING",
    "quick":         "⚡ QUICK",
    "large_context": "📄 LARGE CONTEXT",
}

CHAT_SYSTEM_PROMPT = """You are a helpful, knowledgeable AI assistant. Be conversational, clear, and concise.
- Answer questions directly without unnecessary preamble
- Use markdown formatting when it improves readability (code blocks, lists)
- If the user asks you to make a plan, suggest they click '📋 Plan This' for a structured result
- Keep context from the conversation"""

# Shared model manager
_model_manager = ModelManager()


# ── Helper: resolve model override ───────────────────────────────────────────
def _resolve_model(model_choice: str, goal: str) -> tuple[str, str, str]:
    """Returns (model_name, task_type, task_badge)"""
    task_type = classify_task(goal)
    task_badge = TASK_BADGES.get(task_type, "🧠 GENERAL")

    if model_choice != AUTO_CHOICE:
        return model_choice, task_type, f"{task_badge}  *(manual)*"
    return MODEL_LABELS.get(task_type, "llama3.1:8b"), task_type, task_badge


# ── Planner Tab functions ─────────────────────────────────────────────────────
def generate_plan(goal: str, model_choice: str):
    """
    Streaming generator for the Planner tab.
    Yields: (plan_md, task_badge, model_name, search_status, plan_state)
    """
    if not goal.strip():
        yield "⚠️ Please enter a goal above.", "—", "—", "—", ""
        return

    model_name, task_type, task_badge = _resolve_model(model_choice, goal)
    override = None if model_choice == AUTO_CHOICE else model_choice
    search_needed = needs_search(goal)
    search_status = "✅ Enabled" if search_needed else "❌ Not needed"

    yield f"> ⏳ *Loading **{model_name}**...*", task_badge, model_name, search_status, ""

    try:
        current_plan = ""
        for partial in stream_planner(goal, _model_manager, override):
            current_plan = partial
            yield partial, task_badge, model_name, search_status, current_plan

    except Exception as e:
        error_tb = traceback.format_exc()
        error_md = (
            f"## ❌ Error\n\n"
            f"**{type(e).__name__}:** {e}\n\n"
            f"<details>\n<summary>Full traceback (click to expand)</summary>\n\n"
            f"```\n{error_tb}\n```\n\n"
            f"</details>\n\n"
            f"> 💡 **Tip:** Check that Ollama is running (`ollama serve`) and the model is available (`ollama list`)."
        )
        yield error_md, task_badge, model_name, search_status, ""


def download_plan(plan_text: str):
    """Save the current plan to a temp .md file and return the path for download."""
    if not plan_text.strip():
        return gr.update(visible=False)
    path = os.path.join(tempfile.gettempdir(), "ai_plan.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write(plan_text)
    return gr.update(value=path, visible=True)


# ── Chat Tab functions ────────────────────────────────────────────────────────
def _build_lc_history(history: list) -> list:
    """Convert Gradio chatbot history (list of role/content dicts) to LangChain messages."""
    messages = [SystemMessage(content=CHAT_SYSTEM_PROMPT)]
    for msg in history:
        role    = msg.get("role", "") if isinstance(msg, dict) else ""
        content = msg.get("content", "") if isinstance(msg, dict) else ""
        if role == "user" and content:
            messages.append(HumanMessage(content=str(content)))
        elif role == "assistant" and content:
            messages.append(AIMessage(content=str(content)))
    return messages


def send_chat(message: str, history: list, model_choice: str):
    """
    Stream a chat response.
    History format: list of {"role": str, "content": str} dicts.
    """
    if not message.strip():
        yield history
        return

    model_name, task_type, _ = _resolve_model(model_choice, message)
    override = None if model_choice == AUTO_CHOICE else model_choice

    try:
        if override:
            _model_manager.switch_to_name(override)
        else:
            _model_manager.switch_to(task_type)
        llm = _model_manager.get_llm()
    except Exception as e:
        error_msg = f"❌ **Model Error:** {e}\n\n```\n{traceback.format_exc()}\n```"
        yield history + [
            {"role": "user",      "content": message},
            {"role": "assistant", "content": error_msg},
        ]
        return

    lc_messages = _build_lc_history(history)
    lc_messages.append(HumanMessage(content=message))

    new_history = history + [
        {"role": "user",      "content": message},
        {"role": "assistant", "content": ""},
    ]

    try:
        response = ""
        for chunk in llm.stream(lc_messages):
            response += chunk.content
            new_history[-1]["content"] = response
            yield new_history
    except Exception as e:
        new_history[-1]["content"] = (
            f"❌ **Error during generation:**\n\n"
            f"**{type(e).__name__}:** {e}\n\n"
            f"<details><summary>Traceback</summary>\n\n```\n{traceback.format_exc()}\n```\n</details>"
        )
        yield new_history


def generate_chat_plan(message: str, history: list, model_choice: str):
    """
    Generate a structured plan inside the Chat tab.
    Plan goes to the side panel; chat gets a brief confirmation message.
    Yields: (updated_history, plan_md, plan_state)
    """
    if not message.strip():
        yield history, gr.update(), ""
        return

    override = None if model_choice == AUTO_CHOICE else model_choice

    new_history = history + [
        {"role": "user",      "content": f"📋 *Plan request:* {message}"},
        {"role": "assistant", "content": "> ⏳ *Generating structured plan...*"},
    ]
    yield new_history, "> ⏳ *Generating plan...*", ""

    try:
        plan = ""
        for chunk in stream_planner(message, _model_manager, override):
            plan = chunk
            yield new_history, chunk, ""

        new_history[-1]["content"] = (
            "✅ **Plan generated!** See the **📋 Plan Panel** on the right →\n\n"
            f"> *Goal: {message}*"
        )
        yield new_history, plan, plan

    except Exception as e:
        error_md = (
            f"## ❌ Error\n\n**{type(e).__name__}:** {e}\n\n"
            f"<details><summary>Traceback</summary>\n\n```\n{traceback.format_exc()}\n```\n</details>"
        )
        new_history[-1]["content"] = f"❌ Planning failed: {e}"
        yield new_history, error_md, ""


def clear_chat():
    return [], "", ""  # chatbot, chat_plan_md, chat_plan_state


# ── CSS ───────────────────────────────────────────────────────────────────────
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
* { font-family: 'Inter', sans-serif !important; }

body, .gradio-container {
    background-color: #0d1117 !important;
    color: #e6edf3 !important;
}
.gradio-container { max-width: 1400px !important; margin: 0 auto !important; }

/* Header */
#header {
    background: linear-gradient(135deg, #161b22 0%, #1c2128 100%);
    border: 1px solid #30363d; border-radius: 12px;
    padding: 24px 36px; margin-bottom: 4px; text-align: center;
}
#header h1 {
    font-size: 1.9rem; font-weight: 700;
    background: linear-gradient(90deg, #58a6ff, #bc8cff);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    margin: 0 0 4px 0;
}
#header p { color: #8b949e; font-size: 0.9rem; margin: 0; }

/* Tabs */
.tab-nav button {
    background: transparent !important; color: #8b949e !important;
    border: none !important; border-bottom: 2px solid transparent !important;
    font-size: 0.95rem !important; font-weight: 500 !important;
    padding: 10px 20px !important;
}
.tab-nav button.selected {
    color: #58a6ff !important;
    border-bottom-color: #58a6ff !important;
}

/* Goal / chat input */
textarea {
    background: #161b22 !important; border: 1px solid #30363d !important;
    border-radius: 8px !important; color: #e6edf3 !important;
    font-size: 0.95rem !important; transition: border-color 0.2s !important;
}
textarea:focus { border-color: #58a6ff !important; box-shadow: 0 0 0 3px rgba(88,166,255,0.12) !important; }

/* Labels */
label, .label-wrap { color: #8b949e !important; font-size: 0.78rem !important; font-weight: 600 !important; text-transform: uppercase !important; letter-spacing: 0.08em !important; }

/* Model radio */
.model-radio .wrap {
    background: #161b22 !important; border: 1px solid #30363d !important;
    border-radius: 8px !important; padding: 8px !important; gap: 6px !important; flex-wrap: wrap !important;
}
.model-radio span { background: #1c2128 !important; border: 1px solid #30363d !important; border-radius: 6px !important; color: #8b949e !important; padding: 5px 12px !important; font-size: 0.82rem !important; }
.model-radio input[type="radio"]:checked + span { background: rgba(88,166,255,0.15) !important; border-color: #58a6ff !important; color: #58a6ff !important; font-weight: 600 !important; }

/* Buttons */
#generate-btn, #chat-plan-btn {
    background: linear-gradient(135deg, #238636, #2ea043) !important;
    border: 1px solid #2ea043 !important; border-radius: 8px !important;
    color: white !important; font-weight: 600 !important; width: 100% !important;
    transition: all 0.2s !important;
}
#generate-btn:hover, #chat-plan-btn:hover {
    box-shadow: 0 4px 12px rgba(46,160,67,0.3) !important; transform: translateY(-1px) !important;
}
#stop-btn, #chat-stop-btn {
    background: #161b22 !important; border: 1px solid #f85149 !important;
    border-radius: 8px !important; color: #f85149 !important;
    font-weight: 600 !important; width: 100% !important;
}
#chat-send-btn {
    background: linear-gradient(135deg, #1f6feb, #2f81f7) !important;
    border: 1px solid #2f81f7 !important; border-radius: 8px !important;
    color: white !important; font-weight: 600 !important; width: 100% !important;
}
#download-btn, #chat-download-btn {
    background: #161b22 !important; border: 1px solid #30363d !important;
    border-radius: 8px !important; color: #8b949e !important;
    font-weight: 500 !important; width: 100% !important; transition: all 0.15s !important;
}
#download-btn:hover, #chat-download-btn:hover {
    border-color: #58a6ff !important; color: #58a6ff !important;
}
#clear-btn {
    background: transparent !important; border: 1px solid #30363d !important;
    border-radius: 8px !important; color: #8b949e !important; width: 100% !important;
}

/* Info cards */
.info-card { background: #161b22 !important; border: 1px solid #30363d !important; border-radius: 10px !important; padding: 16px !important; }
.info-card textarea, .info-card input { background: transparent !important; border: none !important; color: #e6edf3 !important; font-size: 0.95rem !important; font-weight: 600 !important; padding: 0 !important; }

/* Plan output (shared between tabs) */
.plan-panel {
    background: #161b22 !important; border: 1px solid #30363d !important;
    border-radius: 10px !important; padding: 24px !important; min-height: 300px !important;
    line-height: 1.75 !important;
}
.plan-panel h1 { font-size: 1.5rem !important; font-weight: 700 !important; color: #58a6ff !important; border-bottom: 1px solid #30363d !important; padding-bottom: 10px !important; }
.plan-panel h2 { font-size: 1.15rem !important; color: #bc8cff !important; margin-top: 24px !important; }
.plan-panel h3 { font-size: 1rem !important; color: #79c0ff !important; margin-top: 16px !important; }
.plan-panel table { width: 100% !important; border-collapse: collapse !important; font-size: 0.88rem !important; }
.plan-panel th { background: #1c2128 !important; color: #8b949e !important; padding: 9px 13px !important; border: 1px solid #30363d !important; text-align: left !important; }
.plan-panel td { padding: 9px 13px !important; border: 1px solid #30363d !important; }
.plan-panel tr:nth-child(even) td { background: #1c2128 !important; }
.plan-panel li { margin: 5px 0 !important; }
.plan-panel code { background: #1c2128 !important; border: 1px solid #30363d !important; border-radius: 4px !important; padding: 2px 6px !important; color: #ff7b72 !important; font-size: 0.86em !important; }
.plan-panel blockquote { border-left: 3px solid #58a6ff !important; padding-left: 14px !important; color: #8b949e !important; margin: 10px 0 !important; font-style: italic !important; }
.plan-panel hr { border: none !important; border-top: 1px solid #30363d !important; margin: 20px 0 !important; }

/* Chatbot */
.chatbot { background: #161b22 !important; border: 1px solid #30363d !important; border-radius: 10px !important; }
.chatbot .message.user { background: rgba(88,166,255,0.1) !important; border: 1px solid rgba(88,166,255,0.2) !important; border-radius: 8px !important; }
.chatbot .message.bot { background: #1c2128 !important; border: 1px solid #30363d !important; border-radius: 8px !important; }

/* Section labels */
.section-label { color: #8b949e !important; font-size: 0.72rem !important; font-weight: 600 !important; text-transform: uppercase !important; letter-spacing: 0.12em !important; margin-bottom: 6px !important; }
.divider { border: none; border-top: 1px solid #30363d; margin: 12px 0; }
"""

# ── Gradio App ────────────────────────────────────────────────────────────────
with gr.Blocks(
    theme=gr.themes.Base(primary_hue="blue", secondary_hue="purple", neutral_hue="gray"),
    css=CSS,
    title="Local AI Planning Agent",
) as demo:

    # ── Header ────────────────────────────────────────────────────────────────
    gr.HTML("""
    <div id="header">
        <h1>🤖 Local AI Planning Agent</h1>
        <p>Powered by Ollama &nbsp;·&nbsp; llama3.1:8b &nbsp;·&nbsp; qwen2.5-coder:7b &nbsp;·&nbsp; gemma4:e2b</p>
    </div>
    """)

    # ── Shared state ──────────────────────────────────────────────────────────
    plan_state = gr.State("")  # current plan text (for download)

    with gr.Tabs():

        # ════════════════════════════════════════════════════════════════════
        # TAB 1 — PLANNER
        # ════════════════════════════════════════════════════════════════════
        with gr.Tab("📋 Planner"):

            goal_input = gr.Textbox(
                placeholder='e.g. "I want to build a SaaS product from scratch"',
                label="Your Goal",
                lines=3, max_lines=6,
            )

            model_radio = gr.Radio(
                choices=MODEL_OPTIONS, value=AUTO_CHOICE,
                label="Model", elem_classes=["model-radio"],
            )

            with gr.Row():
                generate_btn = gr.Button("⚡ Generate Plan", variant="primary", scale=3, elem_id="generate-btn")
                stop_btn     = gr.Button("⏹ Stop", variant="stop", scale=1, elem_id="stop-btn")
                download_btn = gr.Button("📥 Download Plan", scale=1, elem_id="download-btn")
                dl_file      = gr.File(label="", visible=False)

            gr.HTML("<hr class='divider'>")

            with gr.Row(equal_height=False):
                # Left — run info
                with gr.Column(scale=1, min_width=180):
                    gr.HTML("<div class='section-label'>Run Info</div>")
                    task_out   = gr.Textbox(label="Task Type",     value="—", interactive=False, elem_classes=["info-card"])
                    model_out  = gr.Textbox(label="Model",         value="—", interactive=False, elem_classes=["info-card"])
                    search_out = gr.Textbox(label="Web Search",    value="—", interactive=False, elem_classes=["info-card"])

                # Right — plan output
                with gr.Column(scale=4):
                    gr.HTML("<div class='section-label'>Generated Plan</div>")
                    plan_output = gr.Markdown(
                        value="*Your plan will appear here...*",
                        elem_classes=["plan-panel"],
                    )

            gr.HTML("<div style='margin:10px 0 6px;color:#8b949e;font-size:0.78rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em'>Try an Example</div>")
            gr.Examples(
                examples=[
                    ["I want to build a SaaS product from scratch"],
                    ["How do I write a REST API using FastAPI and PostgreSQL"],
                    ["I want to learn machine learning in 6 months"],
                    ["What are the latest AI agent frameworks in 2026"],
                    ["What is a transformer model?"],
                ],
                inputs=goal_input,
                label="",
            )

            # ── Planner events ────────────────────────────────────────────
            click_event = generate_btn.click(
                fn=generate_plan,
                inputs=[goal_input, model_radio],
                outputs=[plan_output, task_out, model_out, search_out, plan_state],
            )
            goal_input.submit(
                fn=generate_plan,
                inputs=[goal_input, model_radio],
                outputs=[plan_output, task_out, model_out, search_out, plan_state],
            )
            stop_btn.click(fn=None, cancels=[click_event])
            download_btn.click(fn=download_plan, inputs=[plan_state], outputs=[dl_file])
            # Show the file component when download is triggered
            plan_state.change(
                fn=lambda t: gr.update(visible=False),
                inputs=[plan_state], outputs=[dl_file],
            )

        # ════════════════════════════════════════════════════════════════════
        # TAB 2 — CHAT
        # ════════════════════════════════════════════════════════════════════
        with gr.Tab("💬 Chat"):

            with gr.Row(equal_height=False):

                # ── Left: chat area ───────────────────────────────────────
                with gr.Column(scale=3):
                    chatbot = gr.Chatbot(
                        height=480,
                        label="",
                        elem_classes=["chatbot"],
                        show_label=False,
                    )

                    chat_msg = gr.Textbox(
                        placeholder="Type a message… (Enter to send)",
                        label="", lines=2, max_lines=4, show_label=False,
                    )

                    with gr.Row():
                        chat_send_btn = gr.Button("💬 Send",       variant="primary", scale=2, elem_id="chat-send-btn")
                        chat_plan_btn = gr.Button("📋 Plan This",  variant="secondary", scale=2, elem_id="chat-plan-btn")
                        chat_stop_btn = gr.Button("⏹ Stop",        variant="stop",      scale=1, elem_id="chat-stop-btn")
                        clear_btn     = gr.Button("🗑 Clear",       scale=1, elem_id="clear-btn")

                    chat_model = gr.Radio(
                        choices=MODEL_OPTIONS, value=AUTO_CHOICE,
                        label="Model", elem_classes=["model-radio"],
                    )

                # ── Right: plan side panel ────────────────────────────────
                with gr.Column(scale=2):
                    gr.HTML("<div class='section-label'>📋 Plan Panel</div>")
                    gr.HTML("<div style='color:#8b949e;font-size:0.8rem;margin-bottom:8px'>Plans generated here stay pinned while you chat →</div>")

                    chat_plan_md = gr.Markdown(
                        value="*No plan yet. Type a goal and click **📋 Plan This**.*",
                        elem_classes=["plan-panel"],
                    )

                    chat_download_btn = gr.Button("📥 Download Plan", elem_id="chat-download-btn")
                    chat_dl_file      = gr.File(label="", visible=False)

                    chat_plan_state = gr.State("")

            # ── Chat events ───────────────────────────────────────────────
            send_event = chat_send_btn.click(
                fn=send_chat,
                inputs=[chat_msg, chatbot, chat_model],
                outputs=[chatbot],
            ).then(fn=lambda: "", outputs=[chat_msg])  # clear input after send

            chat_msg.submit(
                fn=send_chat,
                inputs=[chat_msg, chatbot, chat_model],
                outputs=[chatbot],
            ).then(fn=lambda: "", outputs=[chat_msg])

            plan_event = chat_plan_btn.click(
                fn=generate_chat_plan,
                inputs=[chat_msg, chatbot, chat_model],
                outputs=[chatbot, chat_plan_md, chat_plan_state],
            ).then(fn=lambda: "", outputs=[chat_msg])

            chat_stop_btn.click(fn=None, cancels=[send_event, plan_event])

            clear_btn.click(fn=clear_chat, outputs=[chatbot, chat_plan_md, chat_plan_state])

            chat_download_btn.click(
                fn=download_plan,
                inputs=[chat_plan_state],
                outputs=[chat_dl_file],
            )


if __name__ == "__main__":
    demo.queue().launch(
        server_name="0.0.0.0",
        server_port=7860,
        show_error=True,
        inbrowser=True,
        share=True,
    )
