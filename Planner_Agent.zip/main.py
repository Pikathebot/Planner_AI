import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

from agent.classifier import classify_task
from agent.model_manager import ModelManager
from agent.planner import run_planner, log_run

# ── ANSI color codes ──────────────────────────────────────────────────────────
CYAN   = "\033[96m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

BANNER = f"""
{CYAN}{BOLD}╔══════════════════════════════════════════════════╗
║         Local AI Planning Agent  v2.0           ║
║  Models: llama3.1:8b · qwen2.5-coder · gemma4   ║
╚══════════════════════════════════════════════════╝{RESET}
  Type your goal and press Enter.
  Type {YELLOW}'quit'{RESET} or {YELLOW}'exit'{RESET} to stop.
"""

MODEL_LABELS = {
    "general":       "llama3.1:8b",
    "coding":        "qwen2.5-coder:7b",
    "large_context": "gemma4:e2b",
}


def main():
    print(BANNER)

    # Shared ModelManager — only one Ollama model active at a time (per spec)
    model_manager = ModelManager()

    while True:
        try:
            goal = input(f"\n{BOLD}What needs to be planned?{RESET}\n> ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{YELLOW}Exiting. Goodbye!{RESET}")
            break

        if not goal:
            print("  Please enter a goal.")
            continue

        if goal.lower() in {"quit", "exit", "q"}:
            print(f"\n{YELLOW}Exiting. Goodbye!{RESET}")
            break

        # Show which model will be selected before running
        task_type = classify_task(goal)
        selected_model = MODEL_LABELS[task_type]
        print(f"\n{CYAN}{'─' * 50}{RESET}")
        print(f"  Task type  : {BOLD}{task_type.upper()}{RESET}")
        print(f"  Model      : {BOLD}{selected_model}{RESET}")
        print(f"{CYAN}{'─' * 50}{RESET}")
        print(f"{BOLD}=== AGENT REASONING ==={RESET}")

        try:
            plan = run_planner(goal, model_manager)
            model_name = model_manager.get_model_name() or "unknown"

            print(f"\n{GREEN}{BOLD}{'═' * 50}")
            print("  FINAL PLAN")
            print(f"{'═' * 50}{RESET}")
            print(plan)

            # Auto-log every run
            log_run(goal, task_type, model_name, plan)
            print(f"\n{YELLOW}  ✓ Logged to log.txt{RESET}")

        except Exception as e:
            print(f"\n  [Error] Agent failed: {e}")


if __name__ == "__main__":
    main()